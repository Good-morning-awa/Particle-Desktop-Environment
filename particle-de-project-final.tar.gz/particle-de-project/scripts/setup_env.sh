#!/bin/bash
# ParticleDE 环境设置脚本（完整最终版）
set -e # 遇到错误就退出

echo "[1] 安装必要的软件包..."
sudo apt update
sudo apt install -y openbox tint2 rofi pcmanfm conky-all lightdm feh xterm \
lightdm-gtk-greeter x11-xserver-utils xinit x11-utils imagemagick

echo "[2] 安装 Arc-Dark 主题 + Papirus 图标主题..."
sudo apt install arc-theme -y
sudo add-apt-repository ppa:papirus/papirus -y
sudo apt update
sudo apt install papirus-icon-theme -y

echo "[3] 生成 3 张统一分辨率壁纸..."
mkdir -p ~/Pictures/particle-wallpapers
convert -size 1920x1080 xc:#1a1b26 ~/Pictures/particle-wallpapers/wallpaper-1080p.png
convert -size 2560x1440 xc:#1a1b26 ~/Pictures/particle-wallpapers/wallpaper-2k.png
convert -size 3840x2160 xc:#1a1b26 ~/Pictures/particle-wallpapers/wallpaper-4k.png

echo "[4] 复制配置文件到用户目录..."
mkdir -p ~/.config/openbox ~/.config/tint2 ~/.config/rofi ~/.config/pcmanfm/LXDE

cp -r config/openbox/* ~/.config/openbox/
cp config/tint2/tint2rc ~/.config/tint2/
cp -r config/rofi/* ~/.config/rofi/
cp -r config/pcmanfm/* ~/.config/pcmanfm/

echo "[5] 配置 GTK2/GTK3 全局主题..."
echo 'gtk-theme-name="Arc-Dark"
gtk-icon-theme-name="Papirus-Dark"' > ~/.gtkrc-2.0

mkdir -p ~/.config/gtk-3.0
echo '[Settings]
gtk-theme-name=Arc-Dark
gtk-icon-theme-name=Papirus-Dark' > ~/.config/gtk-3.0/settings.ini

echo "[6] 安装桌面会话文件..."
sudo cp scripts/particlede-session /usr/local/bin/
sudo chmod +x /usr/local/bin/particlede-session
sudo cp config/particlede.desktop /usr/share/xsessions/

echo "[7] 配置完成！"
echo "ParticleDE 完整环境已部署！"
echo "请注销或重启，在登录界面选择 'ParticleDE' 会话。"
echo ""
echo "功能说明："
echo "  - 深色主题 Arc-Dark 已启用"
echo "  - 扁平化图标 Papirus-Dark 已启用"
echo "  - 壁纸自动生成"
echo "  - 面板、启动器、文件管理器全部统一"